Sustale - Undertale based fight mechanics with an Among Us theme

Group Members: Robert, Jason

Responsibilities:
Robert:
- Main fight screen (base functionality, buttons, etc)
- Player Movement
- Collision Detection
- Player Class
- Player and enemy health, displaying health through counters/bars

Jason:
- Title screen (base functionality, buttons, etc)
- Instructions
- Enemy attacks/attack animations (walls, knives, spaceships, balls)
- Player attack mechanism
- End Screen

*Much of the game was worked on together, either in class or on call. This only lists out the major responsibilities each group member took on. Debugging was done mostly together.*


How to play:
- Use arrow keys to select button
- Press z to click button or attack enemy
- Use arrow keys to move player to dodge during enemy attaks
- Goal of the game is to kill the enemy and survive its attacks

Missing Functionalities:
- None

Known Errors/Bugs:
- None

Other Info: 
- All graphics are hand drawn
- Background music was added
- Items can be used without a limit, but if items are used every round, the game cannot be completed